// Pode ser usado para validações, confirmações, etc.
console.log("Sistema de Cartas carregado!");
