<?php
// criando um array do zero
// primeira forma de criação, adicionando um por um

$carros = [];
$carros[] = " ferrari";
$carros[] = " bmw";
$carros[] = " mercedes";


print_r($carros);

?>