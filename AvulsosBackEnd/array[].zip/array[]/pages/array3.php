<?php
// criando arrays dentro de arrays

$motos= [];

$motos[] = [
    "marca" => "kawasaki",
    "modelo" => "vulcan s 650"
];

$motos[] = [
    "marca" => "harley davidson",
    "modelo" => "fat boy"
];
print_r($motos);


?>