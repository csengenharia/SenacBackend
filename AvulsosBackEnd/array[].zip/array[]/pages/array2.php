<?php

// segunda forma, criando com os itens ja inclusos
// adicionando e substituindo itens, nesse caso mercedes por toyota e adiocionando hyundai 

$carros = ["ferrari", "bmw", "mercedes"];
$carros[2] = "toyota";
$carros[3] = "hyundai";


print_r($carros);

?>