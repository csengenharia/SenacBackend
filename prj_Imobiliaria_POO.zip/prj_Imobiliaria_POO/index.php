<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Imobiliária - Sistema</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="menu">
        <h1>Sistema Imobiliária</h1>
        <a href="cliente_cadastro.php">Cadastro de Clientes</a>
        <a href="imovel_cadastro.php">Cadastro de Imóveis</a>
    </div>
</body>
</html>
